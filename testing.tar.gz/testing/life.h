/**
 * @file life.h
 * @brief this program implements the logic of Conway's game of life and renders it using SDL
 * @author Joshua Ashinhurst
 * @date 5 December 2014
 */

#ifndef LIFE_H_
#define LIFE_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "life.h"

unsigned char **init(int rows, int cols);
void free_matrix(unsigned char **a, int rows);
void print(unsigned char **a, int rows, int cols);
void generation_check(unsigned char **A, unsigned char **B, int row, int col, int check);
void copy_matrix(unsigned char **A, unsigned char **B, int row, int col);
void init_pattern(FILE *file, unsigned char **A, int col, int row);
void init_matrix(unsigned char **a, unsigned long row, unsigned long col, int value);
int hedge_life_check(unsigned char **A, int row, int col, int r, int c);
int torus_life_check(unsigned char **A, int row, int col, int y, int x);
int klein_life_check(unsigned char **A, int row, int col, int r, int c);

#endif
