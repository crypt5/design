#ifndef GRAPHICS_H_
#define GRAPHICS_H_

#include <X11/Xlib.h>

#define ESCAPE 0
#define EXIT 1

struct color_t{
        int red;
        int blue;
        int green;
        unsigned long pixel;
};

struct x_info_t{
        Display *dsp;
        Window win;
        GC gc;
        int width;
        int height;
        int sprite_size;
        struct color_t color;
};

/**
 * This function sets up the XServer and window we will use
 * to display the Game of Life
 * @param struct x_info_t* info, A pointer to the structure that will hold
 * all the pointers and objects the library will need
 * @param width, The desired width of the screen
 * @param height, The desired height of the screen
 * @param sprite_size, The desired drawing size.
 * Can only be 2,4,8, or 16. defaults to 2
 * @param red, 0<=red<=255 amount of red in color, default is 255
 * @param green, 0<=green<=255 amount of green in color, default is 255
 * @param blue, 0<=blue<=255 amount of blue in color, default is 255
 */
void x_init(struct x_info_t* info,int width,int height,int sprite_size,int red,int green, int blue);

/**
 * This function renders the pattern held by **life into the 
 * window contained in info.
 * @param struct x_info_t* info, The struct holding all the rendering info
 * @param char** life, The map to be rendered
 */
void x_render_life(struct x_info_t *sdl_info, unsigned char **life);

/**
 * This function polls for events such as a key press and 
 * returns a number of the event
 * @param struct x_info_t* info, The info needed to poll for events
 * @returns Number of the event in header, or -1 if no event, 
 * or one we don't care about.
 */
int x_poll_event(struct x_info_t* info);

/**
 * This function closes connections and frees 
 * The memory called by the library
 * @param struct x_info_t* info, The struct holding all the info
 */
void x_destroy(struct x_info_t* info);

/**
 * This is a simple delay function to slow rendering
 * @param int millis, The number of Milliseconds to pause for
 */
void x_delay(int millis);

#endif
