/**
 * @file gl.c
 * @brief this program implements the logic of Conway's game of life and renders it using SDL
 * @details matrices holding values of 1 or 0, 1 being alive and 0 being dead are used to model a grid. The edges are dealt with using hedge, torus, and klein bottle logic to model a seemingly infiite grid
 * @author Joshua Ashinhurst
 * @date 5 December 2014
 * @todo implement support for 1.05 life files
 * @bug none known
 */

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include "graphics.h"
#include "life.h"

#define HEDGE 22
#define TORUS 33
#define KLEIN 44

int main(int argc, char *argv[])
{
	int width = 800;
	int height = 600;
	int sprite_size = 8; /* either 2, 4, 8, or 16 */
	int ws;
	int hs;
	char edge = KLEIN;
	int c;
	int color;
	int startx = 20;
	int starty = 20;
	int event;
	FILE *life = NULL;
        /* colors are RGB model valid values [0, 255] */
	unsigned char red = 140;
	unsigned char green = 145;
	unsigned char blue = 250;
        struct x_info_t sdl_info;

        unsigned char **A;
        unsigned char **B;
        unsigned char **C;

        while ((c = getopt(argc, argv, ":w:h:e:r:g:b:s:f:o:H")) != -1) {
        	switch(c) {
        	case 'w':
        		width = atoi(optarg);
        		break;
        	case 'h': 
        		height = atoi(optarg);
        		break;
        	case 'e':
        		edge = optarg[0];
        		switch(edge) {
        			case 'h':
        			case 'H':
        				edge = HEDGE;
        				break;
        			case 't':
        			case 'T':
        				edge = TORUS;
        				break;
        			case 'k':
        			case 'K':
        				edge = KLEIN;
        				break;
        		}
        		break;
        	case 'r':
        		color = atoi(optarg);
        		if (color >= 0 && color <= 255) red = color;
        		break;
        	case 'g':
        		color = atoi(optarg);
        		if (color >= 0 && color <= 255) green = color;
        		break;
        	case 'b':
        		color = atoi(optarg);
        		if (color >= 0 && color <= 255) blue = color;
        		break;
        	case 's':
        		sprite_size = atoi(optarg);
        		if (sprite_size != 2 &&
        		    sprite_size != 4 &&
        		    sprite_size != 8 &&
        		    sprite_size != 16) sprite_size = 4;
        		break;
        	case 'f':
        		life = fopen(optarg, "r");
        		break;
        	case 'o':
        		startx = atoi(strtok(optarg, ","));
        		starty = atoi(strtok(NULL, " "));
        		break;
        	case 'H':
        		printf("usage: life [-whergbsfo]\n");
        		printf("w: width of window\n");
        		printf("h: height of window\n");
        		printf("e: type of edge, hedge, klein, or torus\n");
        		printf("r: RGB value for red [0,255]\n");
        		printf("g: RGB value for green [0,255]\n");
        		printf("b: RGB value for blue [0,255]\n");
        		printf("s: sprite size, 2, 4, 8, or 16\n");
        		printf("f: filename for life file\n");
        		printf("o: coordinates for seed of pattern, (x,y), no space\n");
        		exit(EXIT_SUCCESS);
       			break;
       		case ':':
       			printf("%s: option %c requires and argument\n", argv[0], optopt);
       			exit(EXIT_FAILURE);
       			break;
       		case '?':
       		default:
       			printf("illegal option -%c ignored\n", optopt);
       			printf("usage: life [-whergbsfo]\n");
       			break;
        	}

        }

        ws = width/sprite_size;
	hs = height/sprite_size;

	if (!life) {
		life = fopen("101_106.lif", "r");
	}
	if (startx >= ws) {
		startx = 20;
	}
	if (starty >= hs) {
		starty = 10;
	}
        
        /* set up SDL -- works with SDL2 */
	x_init(&sdl_info, width, height, sprite_size, red, green, blue);

	/* your life initialization code here */
		A = init(ws, hs);
		if (!A) {
			exit(ENOMEM);
		}
        	B = init(ws, hs);
        	if (!B) {
			exit(ENOMEM);
		}
		init_matrix(A, ws, hs, 0);
        	init_matrix(B, ws, hs, 0);
        	init_pattern(life, A, startx, starty);
	
        /* Main loop: loop forever. */
	while (1)
	{	

		/* change the  modulus value to slow the rendering */
		x_render_life(&sdl_info, A);

		generation_check(A, B, ws, hs, edge);
		C = A;
		A = B;
		B = C;
	  

                 /* Poll for events, and handle the ones we care about. 
                  * You can click the X button to close the window
                  */
		event=x_poll_event(&sdl_info);
		if(event==EXIT||event==ESCAPE) //Exit conditions
		  break;

		x_delay(100);
		
	}

        /* KEN - I discovered He forgot to close the file */
	/* Everything else he wrote and I only changed the graphics */
	/* Library calls */
	fclose(life);


	free_matrix(A, ws);
	free_matrix(B, ws);
	x_destroy(&sdl_info);
	return 0;
}
