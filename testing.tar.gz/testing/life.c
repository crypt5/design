/**
 * @file life.c
 * @brief this program implements the logic of Conway's game of life and renders it using SDL
 * @details matrices holding values of 1 or 0, 1 being alive and 0 being dead are used to model a grid. The edges are dealt with using hedge, torus, and klein bottle logic to model a seemingly infiite grid
 * @author Joshua Ashinhurst
 * @date 5 December 2014
 * @todo implement support for 1.05 life files
 * @bug none known
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "life.h"

#define HEDGE 22
#define TORUS 33
#define KLEIN 44


/**
 * initializes a matrix that is rows by cols
 * @param rows the number of rows
 * @param cols the number of columns
 * @return pointer to initialized matrix
 */
unsigned char **init(int rows, int cols)
{
        int i;
        int j;
        unsigned char **A;
        A = malloc(rows * sizeof(int *));
        if(!A)
                return NULL;
        for(i = 0; i < rows; i++) { 
                A[i] = malloc(cols * sizeof(int));
                if (!A[i]) {
                        for (j = 0; j < i; j++) 
                                free(A[j]);
                        free(A);
                        return NULL;
                }
        }

        return A;
}
/**
 * frees a created matrix
 * @param a the matrix to be freed
 * @param rows the number of rows
 */
void free_matrix(unsigned char **a, int rows)
{
        int i = 0;
        for(i = 0; i < rows; i++)
                free(a[i]);

        free(a);
}

/**
 * checks the previous generation matrix and creates the new generaton matrix
 * @param A the matrix being checked
 * @param B the matrix for result to be stored in
 * @param row the number of rows in matrix
 * @param col the number of columns in matrix
 * @param check the method for the edge, hedge, torus, or klein
 */
void generation_check(unsigned char **A, unsigned char **B, int row, int col, int check)
{
        int r = 0;
        int c = 0;
        int life = 0;

        switch(check) {
        case HEDGE:
                for ( ; r < row; r++) {
                        for ( ; c < col; c++) {
                                life = hedge_life_check(A, row, col, r, c);
                                if (A[r][c] == 1) {
                                        if (life != 2 && life != 3) {
                                                B[r][c] = 0;
                                        } else {
                                                B[r][c] = 1;
                                        }
                                }
                                if (A[r][c] == 0) {
                                        if (life == 3) {
                                                B[r][c] = 1;
                                        } else {
                                                B[r][c] = 0;
                                        }
                                }
                                life = 0;
                        }
                        c = 0;
                }
        case TORUS:
                for ( ; r < row; r++) {
                        for ( ; c < col; c++) {
                                life = torus_life_check(A, row, col, r, c);
                                if (A[r][c] == 1) {
                                        if (life != 2 && life != 3) {
                                                B[r][c] = 0;
                                        } else {
                                                B[r][c] = 1;
                                        }
                                }
                                if (A[r][c] == 0) {
                                        if (life == 3) {
                                                B[r][c] = 1;
                                        } else {
                                                B[r][c] = 0;
                                        }
                                }
                                life = 0;
                        }
                        c = 0;
                }
                break;
        case KLEIN:
                for ( ; r < row; r++) {
                        for ( ; c < col; c++) {
                                life = klein_life_check(A, row, col, r, c);
                                if (A[r][c] == 1) {
                                        if (life != 2 && life != 3) {
                                                B[r][c] = 0;
                                        } else {
                                                B[r][c] = 1;
                                        }
                                }
                                if (A[r][c] == 0) {
                                        if (life == 3) {
                                                B[r][c] = 1;
                                        } else {
                                                B[r][c] = 0;
                                        }
                                }
                                life = 0;
                        }
                        c = 0;
                }

        }


}

/**
 * creates the seed for the first matrix using given life file text
 * @param file the pointer to the life file text
 * @param A the matrix to be initialized
 * @param col the number of columns in matrix
 * @param row the number of rows in the matrix
 */
void init_pattern(FILE *file, unsigned char **A, int col, int row)
{
        char buf[1024];
        char *s;
        int x;
        int y;

        fgets(buf, 1024, file); /*skips over first line*/
        while(fgets(buf, 1024, file)) {
                s = strtok(buf, " ");
                x = atoi(s);
                s = strtok(NULL, "\n");
                y = atoi(s);
                A[row + y][col + x] = 1;
                while ((s = strtok(NULL, " "))) {
                        y = atoi(s);
                        s = strtok(NULL, "\n");
                        x = atoi(s);
                        A[row  + y][col + x] = 1;
                }
        }
}

/**
 * initializes all values in matrix to given value
 * @param A the matrix to be initialized
 * @param row the number of rows in matrix
 * @param col the number of columns in matrix
 * @param value the value to be initialized with
 */
void init_matrix(unsigned char **A, unsigned long row, unsigned long col, int value)
{
        int i, j;
        for(i = 0; i < row; i++) 
                for(j = 0; j < col; j++)
                        A[i][j] = value;
}

/**
 * checks life for the hedge and returns number of live surrounding cells
 * @param A the matrix to be checked
 * @param row the number of rows in matrix
 * @param col the number of columns in matrix
 * @param r the coordinate for row of the cell being checked
 * @param c the coordinate for column of the cell being checked
 * @return the number of live cells surrounding cell
 */
int hedge_life_check(unsigned char **A, int row, int col, int r, int c)
{
        int i;
        int j;
        int x;
        int y;
        int count = 0;

        for (i = -1; i <= 1; i++) {
                for (j = -1; j <= 1; j++) {
                        if (i == 0 && j == 0) continue;
                        x = r + i;
                        y = c + j;

                        if (x == row ||
                            x == -1  ||
                            y == col ||
                            y == -1) continue;

                        if (A[x][y] == 1) {
                                count++;
                        }
                        
                }
        }


        return count;
}

/**
 * checks life for the torus and returns number of live surrounding cells
 * @param A the matrix to be checked
 * @param row the number of rows in matrix
 * @param col the number of columns in matrix
 * @param r the coordinate for row of the cell being checked
 * @param c the coordinate for column of the cell being checked
 * @return the number of live cells surrounding cell
 */
int torus_life_check(unsigned char **A, int row, int col, int r, int c)
{
        int i = -1;
        int j = -1;
        r += row;
        c += col;
        int count = 0;
        while(i != 2) {
                while(j != 2) {
                        if (i == 0 && j == 0) {
                                j++;
                                continue;
                        }
                        if (A[(r + i) % row][(c + j) % col] == 1) {
                                count++;
                        }
                        j++;
                }
                j = -1;
                i++;
        }

        return count;
}

/**
 * checks life for klein bottle and returns number of live surrounding cells
 * @param A the matrix to be checked
 * @param row the number of rows in matrix
 * @param col the number of columns in matrix
 * @param r the coordinate for row of the cell being checked
 * @param c the coordinate for column of the cell being checked
 * @return the number of live cells surrounding cell
 * @note Evan gave me permission to use the column wrap logic
 */
int klein_life_check(unsigned char **A, int row, int col, int r, int c)
{
        int i;
        int j;
        int x;
        int y;
        int count = 0;

        for (i = -1; i <= 1; i++) {
                for (j = -1; j <= 1; j++) {
                        if (i == 0 && j == 0) continue;
                        x = r + i;
                        y = c + j;
                        if (y == col) {
                                y = 0;
                                x = row - (x + 1);
                        }
                        if (y == -1) {
                                y = col - 1;
                                x = row - (x + 1);
                        }
                        if (x == row) {
                                x = 0;
                        }
                        if (x == -1) {
                                x = row - 1;
                        }
                        if (A[x][y] == 1) {
                                count++;
                        }
                        
                }
        }


        return count;
}