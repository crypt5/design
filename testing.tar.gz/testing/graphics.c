#include <X11/Xlib.h>
#include <X11/keysym.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include "graphics.h"

/**
 * This function sets up the XServer and window we will use
 * to display the Game of Life
 * @param struct x_info_t* info, A pointer to the structure that will hold
 * all the pointers and objects the library will need
 * @param width, The desired width of the screen
 * @param height, The desired height of the screen
 * @param sprite_size, The desired drawing size.
 * Can only be 2,4,8, or 16. defaults to 2
 * @param red, 0<=red<=255 amount of red in color, default is 255
 * @param green, 0<=green<=255 amount of green in color, default is 255
 * @param blue, 0<=blue<=255 amount of blue in color, default is 255
 */
void x_init(struct x_info_t* info,int width,int height,int sprite_size, int red,int green, int blue)
{
         Display *dpy=NULL;
         Screen *scn=NULL;
         Window w;
         GC gc;
         int x_pos,y_pos;
         Atom wm_delete_window;
         struct color_t color;
         int background;
         XColor xcolour;
         Colormap cmap;
	 XEvent e;

         /* Check to see if info exists */
         if(info==NULL){
                  printf("Invalid Value: info struct is NULL\nTerminating\n");
                  exit(-1);
         }

         /* Get a connection to the X Server */
         dpy = XOpenDisplay(NULL);
         if(dpy==NULL){
                  printf("Could not get connection to X Server\nTerminating\n");
                  exit(-2);
         }
         /* Get a pointer to the screen */
         scn=DefaultScreenOfDisplay(dpy);
         if(scn==NULL){
                  printf("Could not get pointer to screen\nTerminating\n");
                  exit(-3);
         }

         /* Get center of the screen */
         x_pos=(scn->width-width)/2;
         y_pos=(scn->height-height)/2;

         /* Store the pointers and values that are needed for rendering */
         info->win=w;
         info->dsp=dpy;
         info->width=width;
	 info->height=height;

	 if(sprite_size==2||sprite_size==4||sprite_size==8||sprite_size==16)
	   	info->sprite_size=sprite_size;
	 else
	   	info->sprite_size=2;

	 if(red>-1&&red<256)
	   	color.red=red;
	 else 
	   	color.red=255;

  	if(green>-1&&green<256)
    		color.green=green;
  	else 
    		color.green=255;

  	if(blue>-1&&blue<256)
    		color.blue=blue;
  	else 
    		color.blue=255;

	/* Create the pixel color and store it */
	cmap = DefaultColormap(dpy, 0);
	xcolour.red = color.red*257;
	xcolour.green = color.green*257;
	xcolour.blue = color.blue*257;
	xcolour.flags = DoRed | DoGreen | DoBlue;
	XAllocColor(dpy, cmap, &xcolour);

	color.pixel=xcolour.pixel;
	info->color=color;

	/* Set up initial background color */
	background= BlackPixel(dpy, DefaultScreen(dpy));

	/* Create and store the window*/
	w = XCreateSimpleWindow(dpy, DefaultRootWindow(dpy), 0, 0, 
				width, height, 0, background, background);

	info->win=w;

	/* Set up atoms to be able to capture exit event */
	wm_delete_window = XInternAtom(dpy, "WM_DELETE_WINDOW", False);
	XSetWMProtocols(dpy, w, &wm_delete_window, 1);

	/* Set the title of the window */
	XStoreName(dpy,w,"Game of Life");

	/* Set up masks to receive the exit and esape key press */
	XSelectInput(dpy, w, StructureNotifyMask | KeyPressMask);

	/* Make the window visible and set to center of screen */
	XMapWindow(dpy, w);
	XMoveWindow(dpy,w,x_pos,y_pos);

	/* Wait for the server to tell us the window is visible */
  	for(;;) {
    		XNextEvent(dpy, &e);
    		if (e.type == MapNotify)
     			 break;
  	}

	/* Create and store the Graphics Context */
	gc=XCreateGC(dpy,w,0,NULL);
	info->gc=gc;

}

/**
 * This function polls for events such as a key press and 
 * returns a number of the event
 * @param struct x_info_t* info, The info needed to poll for events
 * @returns Number of the event in header, or -1 if no event, 
 * or one we don't care about.
 */
int x_poll_event(struct x_info_t* info)
{
        XEvent e;

	/* See if there is an event and fetch is if there is*/
	if(XPending(info->dsp)){
	        XNextEvent(info->dsp,&e);

		/* We only care about the 'x' button and escape key press */
                switch(e.type){
                        case ClientMessage:
                                return EXIT;
                        case KeyPress:
                                if(XLookupKeysym(&e.xkey,0)==XK_Escape)
	                                return ESCAPE;
                }
          }
          /* If not an event we care about return -1 */
          return -1;
}

/**
 * This function closes connections and frees 
 * The memory called by the library
 * @param struct x_info_t* info, The struct holding all the info
 */
void x_destroy(struct x_info_t* info)
{
        /* Xlib created it so Xlib will destroy it */
        XFreeGC(info->dsp,info->gc);

	/* Close the connection to the display */
	XCloseDisplay(info->dsp);

}

/**
 * This function renders the pattern held by **life into the 
 * window contained in info.
 * @param struct x_info_t* info, The struct holding all the rendering info
 * @param char** life, The map to be rendered
 */
void x_render_life(struct x_info_t* info,unsigned char **life)
{
        int rows,cols;
	int i,j;
	int sprite=info->sprite_size;

	rows=info->height/sprite;
	cols=info->width/sprite;

	/* Reset whole map back to black */
	XSetForeground(info->dsp,info->gc,XBlackPixel(info->dsp,0));
	XFillRectangle(info->dsp,info->win,info->gc,0,0,info->width,info->height);

	/* Set drawing color to the color created earlier */
	XSetForeground(info->dsp, info->gc, info->color.pixel);

  /* For every '1' in the life, draw a sprite size cell that color */
        for(i=0;i<cols;i++){
                for(j=0;j<rows;j++){
		        if(life[i][j]==1){
			        XFillRectangle(info->dsp,info->win,info->gc,i*sprite,j*sprite,sprite,sprite);
			}
		}
	}

	/* Push changes to server */
	XFlush(info->dsp);
}

void x_delay(int millis)
{
        usleep(1000*millis);
}
